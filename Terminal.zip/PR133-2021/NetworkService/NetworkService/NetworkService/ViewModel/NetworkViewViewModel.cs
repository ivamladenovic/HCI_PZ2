﻿using NetworkService.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Windows;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Data;
using System.Windows.Shapes;
using System.Windows.Documents;

namespace NetworkService.ViewModel
{
    public class NetworkViewViewModel : BindableBase
    {

        public CollectionViewSource GroupedItems { get; set; }

        public static int monitor = 0;
        private ListView lv;
        public BindingList<EntityBase> Items { get; set; }
        public MyICommand<ListView> MLBUCommand { get; set; }
        public MyICommand<EntityBase> SCCommand { get; set; }
        public MyICommand<Canvas> DCommand { get; set; }
        public MyICommand<Canvas> FreeCommand { get; set; }
        public MyICommand<Canvas> LCommand { get; set; }
        public MyICommand<ListView> LLWCommand { get; set; }
        public MyICommand<Canvas> SCommand { get; set; }
        public ObservableCollection<MyLine> Lines { get; set; } //linije


        Dictionary<int, EntityBase> temp = new Dictionary<int, EntityBase>();
        public static EntityBase draggedItem = null;
        private bool dragging = false;
        private static bool exists = false;
        private int selectedIndex = 0;
        int count = 0;
        private Canvas takenCanvas;
        private List<Canvas> filledCanvases = new List<Canvas>();
        private bool fromList = false;

        public int SelectedIndex
        {
            get { return selectedIndex; }
            set
            {
                selectedIndex = value;
                OnPropertyChanged("SelectedIndex");
            }
        }

        public NetworkViewViewModel()
        {
            Lines = new ObservableCollection<MyLine>();

            // Inicijalizujte CollectionViewSource i postavite izvor na Items
            GroupedItems = new CollectionViewSource();
            GroupedItems.Source = Items;

            // Postavite GroupDescription kako biste grupisali stavke po GroupType
            GroupedItems.GroupDescriptions.Add(new PropertyGroupDescription("GroupType"));
            foreach (EntityBase ob in DataBase.Entities)
            {
                temp.Add(ob.Id, ob);
                count++;
            }
            Items = new BindingList<EntityBase>();
            foreach (var item in DataBase.Entities)
            {
                exists = false;
                foreach (var ex in DataBase.CanvasObjects.Values)
                {
                    if (ex.Id == item.Id)
                    {
                        exists = true;
                        break;
                    }
                }

                if (exists == false)
                    Items.Add(new EntityBase(item));
            }
            MLBUCommand = new MyICommand<ListView>(OnMLBU);
            SCCommand = new MyICommand<EntityBase>(SelectionChange);
            DCommand = new MyICommand<Canvas>(OnDrop);
            FreeCommand = new MyICommand<Canvas>(OnFree);
            LCommand = new MyICommand<Canvas>(OnLoad);
            LLWCommand = new MyICommand<ListView>(OnLLW);
            SCommand = new MyICommand<Canvas>(TeakCanvas);




        }

        public void TeakCanvas(Canvas canvas)
        {
            if (canvas.Resources["taken"] != null)
            {
                draggedItem = DataBase.CanvasObjects[canvas.Name];

                if (!dragging)
                {
                    // Postavljanje flaga za praćenje pomeranja entiteta
                    dragging = true;
                    // Čuvanje referenci na uzeti kanvas i ažuriranje flaga za praćenje
                    takenCanvas = canvas;
                    // Pokretanje akcije pomeranja entiteta
                    DragDrop.DoDragDrop(canvas, draggedItem, DragDropEffects.Copy | DragDropEffects.Move);

                    // Uklanjanje oznake zauzetosti kanvasa
                    canvas.Resources.Remove("taken");
                    TextBlock draggedItemTextBlock = canvas.Children.OfType<TextBlock>().FirstOrDefault(tb => tb.Name == "draggedItemTextBlock");
                    canvas.Children.Remove(draggedItemTextBlock);

                    // Uklanjanje kanvasa iz liste popunjenih kanvsa
                    filledCanvases.Remove(canvas);

                    ConnectCanvasesWithOneLine(filledCanvases);

                    // Povezivanje kanvsa linijom nakon uzimanja
                }
            }
        }

        private void DeleteOldCanvas()
        {
            // Postavljanje boje pozadine na uzetom kanvasu
            takenCanvas.Background = (SolidColorBrush)new BrushConverter().ConvertFrom("#D9D9D9");
            // Uklanjanje entiteta iz baze podataka
            DataBase.CanvasObjects.Remove(takenCanvas.Name);
            // Uklanjanje oznake zauzetosti kanvasa
            takenCanvas.Resources.Remove("taken");
            // Resetovanje reference na uzeti kanvas
            takenCanvas = null;
            ConnectCanvasesWithOneLine(filledCanvases);

        }


        public void OnLLW(ListView listview)
        {
            lv = listview;
        }

        public void OnLoad(Canvas c)
        {
            if (DataBase.CanvasObjects.ContainsKey(c.Name))
            {
                BitmapImage logo = new BitmapImage();
                logo.BeginInit();
                logo.UriSource = new Uri(DataBase.CanvasObjects[c.Name].Type.Picture);
                logo.EndInit();
                c.Background = new ImageBrush(logo);
                c.Resources.Add("taken", true);
                filledCanvases.Add(c);

                monitor++;
                CheckValue(c);

                // Uklonite sve stavke iz Items liste
                Items.Clear();

                // Dodajte sve entitete iz DataBase.Entities u Items listu
                foreach (var item in DataBase.Entities)
                {
                    Items.Add(new EntityBase(item));
                }

                TextBlock draggedItemTextBlock = c.Children.OfType<TextBlock>().FirstOrDefault(tb => tb.Name == "draggedItemTextBlock");
                if (draggedItemTextBlock == null)
                {
                    draggedItemTextBlock = new TextBlock();
                    draggedItemTextBlock.Name = "draggedItemTextBlock";
                    draggedItemTextBlock.VerticalAlignment = VerticalAlignment.Bottom;
                    draggedItemTextBlock.HorizontalAlignment = HorizontalAlignment.Center;
                    draggedItemTextBlock.Width = 48;
                    draggedItemTextBlock.Height = 10;
                    draggedItemTextBlock.FontSize = 8; // Set font size
                    draggedItemTextBlock.TextWrapping = TextWrapping.Wrap;
                    draggedItemTextBlock.Background = Brushes.Transparent; // Set white background
                    draggedItemTextBlock.Margin = new Thickness(3, 0, 0, 0);
                    draggedItemTextBlock.FontWeight = FontWeights.Medium;


                    c.Children.Add(draggedItemTextBlock);
                }
                draggedItemTextBlock.Text = $"ID: {DataBase.CanvasObjects[c.Name].Id} V: {DataBase.CanvasObjects[c.Name].Value}";
                ConnectCanvasesWithOneLine(filledCanvases);

            }
        }


        public void OnFree(Canvas c)
        {
            try
            {
                if (c.Resources["taken"] != null)
                {
                    c.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#D9D9D9"));
                    ((Border)c.Children[0]).BorderBrush = Brushes.Transparent;

                    // Ukloni tekst iz TextBlock-a
                    TextBlock draggedItemTextBlock = c.Children.OfType<TextBlock>().FirstOrDefault(tb => tb.Name == "draggedItemTextBlock");
                    if (draggedItemTextBlock != null)
                    {
                        c.Children.Remove(draggedItemTextBlock);
                    }

                    // Provera da li entitet već postoji u Items listi pre nego što ga dodamo
                    bool entityExists = false;
                    foreach (var item in DataBase.Entities)
                    {
                        if (DataBase.CanvasObjects.ContainsKey(c.Name) && DataBase.CanvasObjects[c.Name].Id == item.Id)
                        {
                            entityExists = true;
                            break;
                        }
                    }

                    if (!entityExists)
                    {
                        foreach (var item in DataBase.Entities)
                        {
                            if (!Items.Contains(item) && DataBase.CanvasObjects[c.Name].Id == item.Id)
                            {
                                Items.Add(new EntityBase(item));
                            }
                        }
                    }

                    c.Resources.Remove("taken");
                    filledCanvases.Remove(c);

                    DataBase.CanvasObjects.Remove(c.Name);
                    ConnectCanvasesWithOneLine(filledCanvases);


                }
                monitor--;
            }
            catch (Exception) { }
        }

        public void OnDrop(Canvas c)
        {
            if (draggedItem != null)
            {
                if (c.Resources["taken"] == null)
                {
                    BitmapImage logo = new BitmapImage();
                    logo.BeginInit();
                    logo.UriSource = new Uri(draggedItem.Type.Picture);
                    logo.EndInit();
                    c.Background = new ImageBrush(logo);


                    c.Resources.Add("taken", true);

                    filledCanvases.Add(c);
                    Grid parentGrid = FindChild<Grid>(Application.Current.MainWindow, "MainGrid");


                    if (fromList)
                    {
                        Items.Remove(Items.Single(x => x.Id == draggedItem.Id));
                    }

                    // Proverite da li postoji stari kanvas
                    if (takenCanvas != null)
                    {
                        if (fromList)
                        {
                            DataBase.CanvasObjects[c.Name] = draggedItem;
                            fromList = false;
                        }
                        else
                        {
                            DataBase.CanvasObjects[c.Name] = draggedItem;
                            DeleteOldCanvas();
                        }
                    }
                    else
                    {
                        // Ako ne postoji stari kanvas, samo dodajte novi u bazu podataka
                        DataBase.CanvasObjects[c.Name] = draggedItem;
                    }

                    SelectedIndex = 0;
                    monitor++;
                    CheckValue(c);
                    TextBlock draggedItemTextBlock = c.Children.OfType<TextBlock>().FirstOrDefault(tb => tb.Name == "draggedItemTextBlock");
                    if (draggedItemTextBlock == null)
                    {
                        draggedItemTextBlock = new TextBlock();
                        draggedItemTextBlock.Name = "draggedItemTextBlock";
                        draggedItemTextBlock.VerticalAlignment = VerticalAlignment.Bottom;
                        draggedItemTextBlock.HorizontalAlignment = HorizontalAlignment.Center;
                        draggedItemTextBlock.Width = 48;
                        draggedItemTextBlock.Height = 10;
                        draggedItemTextBlock.FontSize = 8; // Set font size
                        draggedItemTextBlock.TextWrapping = TextWrapping.Wrap;
                        draggedItemTextBlock.Background = Brushes.Transparent; // Set white background
                        draggedItemTextBlock.Margin = new Thickness(3, 0, 0, 0);
                        draggedItemTextBlock.FontWeight = FontWeights.Medium;

                        c.Children.Add(draggedItemTextBlock);
                    }

                    // Postavite tekst u TextBlock
                    draggedItemTextBlock.Text = $"ID: {draggedItem.Id} V: {draggedItem.Value}";
                    ConnectCanvasesWithOneLine(filledCanvases);


                    dragging = false; // Resetujemo flag za pomeranje objekta

                }
            }
        }



        public void OnMLBU(ListView lw)
        {
            draggedItem = null;
            lw.SelectedItem = null;
            dragging = false;
        }

        public void SelectionChange(EntityBase o)
        {
            if (!dragging)
            {
                dragging = true;
                draggedItem = new EntityBase(o);
                DragDrop.DoDragDrop(lv, draggedItem, DragDropEffects.Move);
            }
        }

        private void CheckValue(Canvas c)
        {

            foreach (EntityBase ob in DataBase.Entities)
            {
                temp[ob.Id] = ob;
            }
            Task.Delay(1000).ContinueWith(_ =>
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    if (DataBase.CanvasObjects.Count != 0)
                    {
                        if (DataBase.CanvasObjects.ContainsKey(c.Name))
                        {
                            if (temp[DataBase.CanvasObjects[c.Name].Id].Value > 5 || temp[DataBase.CanvasObjects[c.Name].Id].Value < 1)
                            {
                                ((Border)c.Children[0]).BorderBrush = Brushes.DarkRed;
                            }
                            else
                            {
                                ((Border)c.Children[0]).BorderBrush = Brushes.Transparent;
                            }
                        }
                        else
                        {
                            ((Border)c.Children[0]).BorderBrush = Brushes.Transparent;
                        }
                    }
                });
                CheckValue(c);
            });


        }
        private UserControl _view;
        private T FindChild<T>(DependencyObject parent, string childName) where T : DependencyObject
        {
            // Proveri sve children elemente
            int childCount = VisualTreeHelper.GetChildrenCount(parent);

            for (int i = 0; i < childCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                // Ako je dete željenog tipa i ima traženo ime
                if (child is T typedChild && (typedChild as FrameworkElement)?.Name == childName)
                {
                    return typedChild;
                }

                // Rekurzivno pretraživanje u children elementima
                var foundChild = FindChild<T>(child, childName);
                if (foundChild != null)
                {
                    return foundChild;
                }
            }

            return null;
        }

        private void ConnectCanvasesWithOneLine(List<Canvas> canvases)
        {
            // Filtriraj samo popunjene kanvase
            var filledCanvases = canvases.Where(c => c.Resources.Contains("taken")).ToList();

            if (filledCanvases.Count < 2)
                return;

            Grid parentGrid = FindChild<Grid>(Application.Current.MainWindow, "MainGrid");
            if (parentGrid == null)
                return;

            // Ukloni postojeće linije
            var existingLines = parentGrid.Children.OfType<Line>().ToList();
            foreach (var line in existingLines)
            {
                parentGrid.Children.Remove(line);
            }

            // Poveži sve popunjene kanvase linijama
            for (int i = 0; i < filledCanvases.Count - 1; i++)
            {
                Canvas canvas1 = filledCanvases[i];
                Canvas canvas2 = filledCanvases[i + 1];

                Point canvas1Pos = canvas1.TransformToAncestor(parentGrid).Transform(new Point(0, 0));
                Point canvas2Pos = canvas2.TransformToAncestor(parentGrid).Transform(new Point(0, 0));

                // Tačna pozicija centra kanvasa
                Point canvas1Center = new Point(canvas1Pos.X + canvas1.ActualWidth / 2, canvas1Pos.Y + canvas1.ActualHeight / 2);
                Point canvas2Center = new Point(canvas2Pos.X + canvas2.ActualWidth / 2, canvas2Pos.Y + canvas2.ActualHeight / 2);

                Line line = new Line
                {
                    X1 = canvas1Center.X,
                    Y1 = canvas1Center.Y,
                    X2 = canvas2Center.X,
                    Y2 = canvas2Center.Y,
                    Stroke = Brushes.Yellow,
                    StrokeThickness = 2,
                    StrokeStartLineCap = PenLineCap.Round,
                    StrokeEndLineCap = PenLineCap.Round,
                    IsHitTestVisible = false
                };

                parentGrid.Children.Add(line);
            }
        }

    }




}







