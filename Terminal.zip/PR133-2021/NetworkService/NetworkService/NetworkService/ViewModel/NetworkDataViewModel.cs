﻿using NetworkService.Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Xml.Linq;

namespace NetworkService.ViewModel
{
    public class NetworkDataViewModel : BindableBase
    {
        private DataBase dataBase = new DataBase();
        public List<EntityBase> SerachEntities = new List<EntityBase>();
        public ObservableCollection<EntityBase> CopyEntities { get; set; } = new ObservableCollection<EntityBase>();
        public Dictionary<int, EntityBase> Reserve { get; set; } = new Dictionary<int, EntityBase>();
        public List<string> ComboBoxData { get; set; }      //kombo box za pretragu 

        Stack stekAdd = new Stack();
        Stack stekDelete = new Stack();
        Stack bol = new Stack();

        bool addUndo, deleteUndo = false;
        public List<string> ComboBoxDataEntities { get; set; }   // za dodavanje
        private DataChartViewModel dataChartViewModel = new DataChartViewModel();
        public static MyICommand<string> AddCommand { get; set; }
        public static MyICommand<string> SearchCommandConsole { get; set; }
        public static MyICommand AddCommandBtn { get; set; }  //komande za dugmice
        public static MyICommand<string> DeleteCommand { get; set; }
        public static MyICommand DeleteCommandBtn { get; set; }
        public MyICommand SearchCommand { get; set; }
        public MyICommand NameSearchCommand { get; set; }
        public static MyICommand<string> UndoCommand { get; set; }
        public MyICommand TypeSearchCommand { get; set; }
        public ObservableCollection<EntityBase> Entities3 { get; set; } = new ObservableCollection<EntityBase>();

        private string idSearch;
        private string typeText;
        private string id;
        private string name;
        private string searchValueText;
        private int nameOrType = -1;

        private int index = -1;
        private string path;
        private int clickSearch = 0;
        private string nameButtonSearch = "Search";
        private string idValidationMessage;
        private string nameValidationMessage;
        private string typeValidationMessage;



        public NetworkDataViewModel()
        {
            if (Entities3.Count() > 0)
            {
                Entities3.Clear();
            }
            foreach (var i in DataBase.Entities)
            {
                Entities3.Add(i);
            }
            ComboBoxData = new List<string>();
            ComboBoxDataEntities = new List<string> { "Solar", "Air" };
            foreach (EntityBase r in Entities3)
            {
                if (!Reserve.ContainsKey(r.Id))
                {
                    Reserve.Add(r.Id, r);
                }
            }




            NameOrType = 0;
            UndoCommand = new MyICommand<string>(OnUndo);
            AddCommand = new MyICommand<string>(OnAdd);
            AddCommandBtn = new MyICommand(OnAddBtn);
            DeleteCommand = new MyICommand<string>(OnDelete);
            DeleteCommandBtn = new MyICommand(OnDeleteBtn);
            SearchCommand = new MyICommand(OnSearch);
            NameSearchCommand = new MyICommand(OnName);
            TypeSearchCommand = new MyICommand(OnType);
            SearchCommandConsole = new MyICommand<string>(OnSearchConsole);
        }
        public DataBase DataBase
        { get => dataBase; set => dataBase = value; }

        private bool _isDeleteButtonValid = true;
        public bool IsDeleteButtonValid
        {
            get { return _isDeleteButtonValid; }
            set
            {
                _isDeleteButtonValid = value;
                OnPropertyChanged(nameof(IsDeleteButtonValid));
            }
        }

        private void OnDeleteBtn()
        {
            if (Entities3.Count == 0)
            {
                MessageBox.Show("There are no items to delete.", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (Index < 0 || Index >= Entities3.Count)
            {
                IsDeleteButtonValid = false;
                MessageBox.Show("No item selected to delete.", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            IsDeleteButtonValid = true; // Reset the delete button validation state

            var result = MessageBox.Show("Are you sure you want to delete this entity?", "Confirmation", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.No)
            {
                return;
            }

            bool valid = true;
            foreach (EntityBase v in DataBase.CanvasObjects.Values)
            {
                if (v.Name == Entities3[Index].Name)
                {
                    valid = false;
                    MessageBox.Show("Entity is on monitoring", "Warning!", MessageBoxButton.OK, MessageBoxImage.Error);
                    break;
                }
            }

            if (valid)
            {
                int i = Index;
                bol.Push(false);
                stekDelete.Push(DataBase.Entities[i]);
                DataBase.Entities.RemoveAt(i);
                Entities3.RemoveAt(i);
            }
        }



        //private bool CanAdd()
        //{
        //    if (TypeText != null && Name != null && Name != "")//provera da li je odabran tip reaktora
        //    {
        //        return true;
        //    }
        //    return false;

        //}

        public int NameOrType
        {
            get { return nameOrType; }
            set
            {
                nameOrType = value;
            }
        }


   
        public string IdValidationMessage
        {
            get => idValidationMessage;
            set => SetProperty(ref idValidationMessage, value);
        }
        public string NameValidationMessage
        {
            get => nameValidationMessage;
            set => SetProperty(ref nameValidationMessage, value);
        }
        public string TypeValidationMessage
        {
            get => typeValidationMessage;
            set => SetProperty(ref typeValidationMessage, value);
        }
        private void OnAddBtn()
        {
            bool hasError = false;
            if (string.IsNullOrWhiteSpace(Id))
            {
                IdValidationMessage = "ID is required";
                hasError = true;
            }
            else if (!Int32.TryParse(Id, out idInt))
            {
                IdValidationMessage = "ID must be an integer";
                hasError = true;
            }
            else
            {
                IdValidationMessage = ""; // Clear ID validation message if ID is valid
            }

            // Check Name
            if (string.IsNullOrWhiteSpace(Name))
            {
                NameValidationMessage = "Name can't be empty";
                hasError = true;
            }
            else
            {
                NameValidationMessage = ""; // Clear Name validation message if Name is valid
            }

            // Check Type
            if (TypeText != "Solar" && TypeText != "Air")
            {
                TypeValidationMessage = "Please select a valid type (Solar or Air)";
                hasError = true;
            }
            else
            {
                TypeValidationMessage = ""; // Clear Type validation message if Type is valid
            }

            // Return if there are any validation errors
            if (hasError)
            {
                return;
            }

            // Check if the ID already exists
            bool exists = DataBase.Entities.Any(v => v.Id == idInt);
            if (exists)
            {
                IdValidationMessage = "Generator with that ID already exists";
                return;
            }

            // Proceed with adding the new entity
            string type = TypeText == "Solar" ? "Solar" : "Air";
            EntityBase newEntity = new EntityBase
            {
                Id = idInt,
                Name = Name,
                Type = { Name = type }
            };

            string pathImg = Environment.CurrentDirectory;
            pathImg = pathImg.Remove(pathImg.Length - 10, 10);
            pathImg += @"\Images\" + TypeText + ".png";
            newEntity.Type.Picture = pathImg;

            stekAdd.Push(newEntity);
            bol.Push(true);
            Entities3.Add(newEntity);
            DataBase.Entities.Add(newEntity);
            if (!Reserve.ContainsKey(newEntity.Id))
            {
                Reserve.Add(newEntity.Id, newEntity);
            }

            // Clear all validation messages on successful add
            IdValidationMessage = "";
            NameValidationMessage = "";
            TypeValidationMessage = "";
        }


        public string IdSearch
        {
            get { return idSearch; }
            set
            {
                idSearch = value;
                OnPropertyChanged("IdSearch");   //kad properti dobije vrednost vrednost se setuje u xaml i obrnuto         
                SearchCommand.RaiseCanExecuteChanged();
            }
        }

        public string Id
        {
            get { return id; }
            set
            {
                id = value;
                OnPropertyChanged("Id");
                AddCommandBtn.RaiseCanExecuteChanged();
            }
        }
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged("Name");
                AddCommandBtn.RaiseCanExecuteChanged();
            }
        }
        public string TypeText
        {
            get { return typeText; }
            set
            {
                typeText = value;
                Path = Environment.CurrentDirectory;
                Path = Path.Remove(Path.Length - 10, 10);
                Path += @"\Images\" + value + ".png";
                AddCommandBtn.RaiseCanExecuteChanged(); //properti dobio vrednost proveri da li moze da se aktivira button koji je povezan na ovu komandu
            }
        }
        public string SearchValueText
        {
            get { return searchValueText; }
            set
            {
                searchValueText = value;
                OnPropertyChanged("SearchValueText");
                SearchCommand.RaiseCanExecuteChanged();
            }
        }

        public string Path
        {
            get { return path; }
            set
            {
                path = value;
                OnPropertyChanged("Path");
            }
        }



        public int ClickSearch
        {
            get { return clickSearch; }
            set
            {
                clickSearch = value;
                if (value == 0)
                    NameButtonSearch = "Pretrazi";
                else
                    NameButtonSearch = "Refresuj";
            }
        }

        public string NameButtonSearch
        {
            get { return nameButtonSearch; }
            set
            {
                nameButtonSearch = value;
                OnPropertyChanged("NameButtonSearch");
            }
        }

        public int idInt;


        private void OnUndo(string a)
        {
            if (bol.Count > 0)
            {
                if ((bool)bol.Peek()) // poslednje je dodato
                {
                    bol.Pop();
                    EntityBase r = new EntityBase();
                    r = (EntityBase)stekAdd.Pop();
                    EntityBase zaBrisanje = new EntityBase();
                    int j = -1;
                    if (r != null)  //Zadnje je dodato sada ga brise
                    {
                        if (Entities3.Contains(r))
                        {
                            deleteUndo = true;

                            stekDelete.Push(DataBase.Entities.Last());
                            DataBase.Entities.Remove(r);
                            Entities3.Remove(r);
                        }
                    }
                    addUndo = false;
                }
                else
                {
                    bol.Pop();
                    EntityBase r = new EntityBase();
                    r = (EntityBase)stekDelete.Pop();
                    DataBase.Entities.Add(r);
                    Entities3.Add(r);
                }
            }
        }


        private void OnSearchConsole(string s)
        {
            string[] p = s.Split('(', ')', ',');

            if (p[1] == "type")
            {
                foreach (var item in Entities3)
                {
                    if (item.Type.Name.Contains(p[2]))
                    {
                        SerachEntities.Add(item);
                    }
                }

                Entities3.Clear();
                foreach (EntityBase v in SerachEntities)
                {
                    Entities3.Add(v);
                }
                SerachEntities.Clear();
                ClickSearch = 1;

            }
            else if (p[1] == "name")
            {
                foreach (var item in Entities3)
                {
                    if (item.Name.Contains(p[2]))
                    {
                        SerachEntities.Add(item);
                    }
                }
                Entities3.Clear();
                foreach (EntityBase v in SerachEntities)
                {
                    Entities3.Add(v);
                }
                SerachEntities.Clear();
                ClickSearch = 1;
            }
            else
            {
                MessageBox.Show("Unknown parameters", "Warning", MessageBoxButton.OK, MessageBoxImage.Error);
            }


        }

        private void OnDelete(string s)
        {

            EntityBase r = new EntityBase();
            bool postoji = false;
            bool valid = true;
            string[] p = s.Split('(', ')', ',');
            if (Int32.TryParse(p[1], out idInt))
            {
                if (p.Length == 3)
                {
                    foreach (EntityBase v in DataBase.CanvasObjects.Values)
                    {
                        if (v.Id == idInt)
                        {
                            valid = false;
                            MessageBox.Show("Generator is on monitoring", "Warning!", MessageBoxButton.OK, MessageBoxImage.Error);
                            break;
                        }
                    }

                    if (valid != false)
                    {
                        if (DataBase.Entities.Count != 0)
                        {
                            foreach (EntityBase v in DataBase.Entities)
                            {
                                if (idInt == v.Id)
                                {
                                    postoji = true;
                                    r = v;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("No entity to delete", "Warning!", MessageBoxButton.OK, MessageBoxImage.Error);
                        }

                        if (postoji)
                        {
                            bol.Push(false);
                            stekDelete.Push(r);
                            DataBase.Entities.Remove(r);
                            Entities3.Remove(r);

                        }
                        else
                        {
                            MessageBox.Show("No entity with that id.", "Warning!", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Unknown command", "Warning!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }





        private void OnAdd(string s)
        {
            string[] p = s.Split('(', ')', ',');

            if (p.Length == 5)
            {
                if (Int32.TryParse(p[1], out idInt))
                {
                    bool postoji = false;
                    if (DataBase.Entities.Count != 0)
                    {
                        foreach (EntityBase v in DataBase.Entities)
                        {
                            if (idInt == v.Id)
                            {
                                MessageBox.Show("Entity with that id already exists.", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);
                                postoji = true;
                            }
                        }
                    }

                    if (!postoji)
                    {
                        if (p[3] == "Air" || p[3] =="Solar")
                        {
                            string type;
                            if (p[3] == "Solar")
                            {
                                type = "Solar";
                            }
                            else
                            {
                                type = "Air";
                            }
                            EntityBase i = new EntityBase();
                            i.Id = idInt;
                            i.Name = p[2];
                            i.Type.Name = type;
                            string pathImg = Environment.CurrentDirectory;
                            pathImg = pathImg.Remove(pathImg.Length - 10, 10);
                            pathImg += @"\Images\" + type + ".png";
                            i.Type.Picture = pathImg;
                            stekAdd.Push(i);
                            bol.Push(true);
                            Entities3.Add(i);
                            DataBase.Entities.Add(i);
                            foreach (EntityBase r in DataBase.Entities)
                            {
                                if (!Reserve.ContainsKey(r.Id))
                                {
                                    Reserve.Add(r.Id, r);
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Unknown type", "Warning!", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }

                    }
                }
                else
                {
                    MessageBox.Show("Id must be a number", "Warning!", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                MessageBox.Show("Unknown command", "Error!", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void OnName()
        {
            NameOrType = 0;
        }
        public void OnType()
        {
            NameOrType = 1;
        }

        //private bool CanSearch()
        //{
        //    if (SearchValueText != null && SearchValueText != "")
        //        return true;
        //    return false;
        //}
        private SolidColorBrush _nameBorderBrush = new SolidColorBrush(Colors.Black);
        private SolidColorBrush _typeBorderBrush = new SolidColorBrush(Colors.Black);
        private string _radioErrorMessage;

        public SolidColorBrush NameBorderBrush
        {
            get { return _nameBorderBrush; }
            set { SetProperty(ref _nameBorderBrush, value); }
        }

        public SolidColorBrush TypeBorderBrush
        {
            get { return _typeBorderBrush; }
            set { SetProperty(ref _typeBorderBrush, value); }
        }

        public string RadioErrorMessage
        {
            get { return _radioErrorMessage; }
            set { SetProperty(ref _radioErrorMessage, value); }
        }


        private void OnSearch()
        {
            if (NameOrType == -1)
            {
                NameBorderBrush = new SolidColorBrush(Colors.DarkRed);
                TypeBorderBrush = new SolidColorBrush (Colors.DarkRed);

                return;
            }

            // Ako je odabrana opcija za pretragu, postavljamo boju obruba na crnu i brišemo poruku o grešci
            NameBorderBrush = new SolidColorBrush(Colors.Black);
            TypeBorderBrush = new SolidColorBrush(Colors.Black);

            if (string.IsNullOrWhiteSpace(SearchValueText))
            {
                RadioErrorMessage = "Please enter name or type for search."; // Postavljanje poruke ako polje za unos teksta nije popunjeno
                return;
            }
            else 
            {

                RadioErrorMessage = "";

            }


            if (ClickSearch == 0)    //1 kad moze undo inace 0
            {
                foreach (EntityBase r in Entities3)
                {
                    CopyEntities.Add(r);
                }

                if (NameOrType == 0) // name
                {
                    foreach (var item in Entities3)
                    {
                        if (item.Name.Contains(SearchValueText))
                        {
                            SerachEntities.Add(item);
                        }
                    }
                }
                else if (NameOrType == 1) // type
                {
                    foreach (var item in Entities3)
                    {
                        if (item.Type.Name.Contains(SearchValueText))
                        {
                            SerachEntities.Add(item);
                        }
                    }

                }
                Entities3.Clear();
                foreach (EntityBase v in SerachEntities)
                {
                    Entities3.Add(v);
                }
                SerachEntities.Clear();
                ClickSearch = 1;

            }
            else
            {
                Entities3.Clear();
                foreach (EntityBase v in Reserve.Values)
                {
                    Entities3.Add(v);
                }
                CopyEntities.Clear();
                ClickSearch = 0;
            }
        }
        public int Index
        {
            get { return index; }
            set
            {
                index = value;
                DeleteCommandBtn.RaiseCanExecuteChanged();
            }
        }

        //private bool CanDelete()
        //{
        //    return index >= 0;
        //}
    }
}
