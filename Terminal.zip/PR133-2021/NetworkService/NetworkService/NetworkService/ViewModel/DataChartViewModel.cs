﻿using NetworkService.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace NetworkService.ViewModel
{
    public class DataChartViewModel : BindableBase
    {
        public Dictionary<int, EntityBase> ComboBoxData { get; set; }   // za dodavanje
        public static GraphUpdater ElementHeights { get; set; } = new GraphUpdater();
        private static int reactorChoice;
        public static MyICommand<string> PlotCommand { get; set; }


        public DataChartViewModel()
        {
            ComboBoxData = new Dictionary<int, EntityBase>();
            PlotCommand = new MyICommand<string>(OnPlot);
            foreach (EntityBase r in DataBase.Entities)
            {
                if (!ComboBoxData.ContainsKey(r.Id))
                {
                    ComboBoxData.Add(r.Id, r);
                }
            }

        }

        private List<string> measurementValues = new List<string>();
        public List<string> MeasurementValues
        {
            get { return measurementValues; }
            set
            {
                measurementValues = value;
                OnPropertyChanged("MeasurementValues");
            }
        }
        //private List<string> dates = new List<string>();
        //public List<string> Dates
        //{
        //    get { return dates; }
        //    set
        //    {
        //        dates = value;
        //        OnPropertyChanged("Dates");
        //    }
        //}

        public int idInt;

      private void OnPlot(string s)
        {
            bool postoji = false;
            EntityBase r = new EntityBase();
            string[] p = s.Split('(', ')', ',');

            if (Int32.TryParse(p[1], out idInt))
            {
                foreach (EntityBase v in DataBase.Entities)
                {
                    if (idInt == v.Id)
                    {
                        postoji = true;
                        r = v;
                    }
                }
            }
            else
            {
                MessageBox.Show("Parameter must be a number", "Warning!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            if (postoji)
            {
                EntityChoice = r.Id;
            }
            else
            {
                MessageBox.Show("Entity with that id doesn't exist", "Warning!", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }



        public static int EntityChoice
        {
            get { return reactorChoice; }
            set
            {
                reactorChoice = value;
                List<int> vrijednost = new List<int>();
                List<DateTime> dates = new List<DateTime>();

                string[] lines = File.ReadAllLines("Log.txt");
                List<String> l = lines.ToList();
                l.Reverse();
                foreach (string s in l)
                {
                    DateTime dt = DateTime.Parse($"{s.Split(':', '|')[5]}:{s.Split(':', '|')[6]}:{s.Split(':', '|')[7]}".Trim());
                    int id = int.Parse(s.Split(':', '|')[1]);
                    if (id == EntityChoice)
                    {
                        vrijednost.Add(int.Parse(s.Split(':', '|')[3]));

                        dates.Add(dt);

                    }

                    if (dates.Count == 5)
                        break;
                }
                int duzina = vrijednost.Count();
                int a = 12;



                if (duzina >= 1)
                {
                    if (vrijednost[0] <= 5 && vrijednost[0] > 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina1 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[0]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja1 = "Green";
                        ViewModel.DataChartViewModel.ElementHeights.FirstTime = DateTime.Now.ToString("HH:mm");
                        ViewModel.DataChartViewModel.ElementHeights.Merenje1 = vrijednost[0].ToString();


                    }
                    else if (vrijednost[0] > 5 || vrijednost[0] == 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina1 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[0]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja1 = "Red";
                        ViewModel.DataChartViewModel.ElementHeights.FirstTime = DateTime.Now.ToString("HH:mm");
                        ViewModel.DataChartViewModel.ElementHeights.Merenje1 = vrijednost[0].ToString();





                    }
                }
                else
                {
                    ViewModel.DataChartViewModel.ElementHeights.Visina1 = 0;
                }

                if (duzina >= 2)
                {
                    if (vrijednost[1] <= 5 && vrijednost[1] > 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina2 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[1]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja2 = "Green";
                        ViewModel.DataChartViewModel.ElementHeights.SecondTime = DateTime.Now.ToString("HH:mm");
                        if(duzina >= 2)
                        {
                            ViewModel.DataChartViewModel.ElementHeights.Merenje2 = vrijednost[0].ToString();
                            ViewModel.DataChartViewModel.ElementHeights.Merenje1 = vrijednost[1].ToString();

                        }





                    }
                    else if (vrijednost[1] > 5 || vrijednost[1] == 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina2 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[1]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja2 = "Red";
                        ViewModel.DataChartViewModel.ElementHeights.SecondTime = DateTime.Now.ToString("HH:mm");
                        ViewModel.DataChartViewModel.ElementHeights.Merenje2 = vrijednost[1].ToString();
                        if (duzina >= 2)
                        {
                            ViewModel.DataChartViewModel.ElementHeights.Merenje2 = vrijednost[0].ToString();
                            ViewModel.DataChartViewModel.ElementHeights.Merenje1 = vrijednost[1].ToString();

                        }

                    }
                }
                else
                {
                    ViewModel.DataChartViewModel.ElementHeights.Visina2 = 0;
                }

                if (duzina >= 3)
                {
                    if (vrijednost[2] <= 5 && vrijednost[2] > 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina3 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[2]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja3 = "Green";
                        ViewModel.DataChartViewModel.ElementHeights.ThirdTime = DateTime.Now.ToString("HH:mm");
                       

                    }
                    else if (vrijednost[2] > 5 || vrijednost[2] == 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina3 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[2]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja3 = "Red";
                        ViewModel.DataChartViewModel.ElementHeights.ThirdTime = DateTime.Now.ToString("HH:mm");
                      


                    }
                }
                else
                {
                    ViewModel.DataChartViewModel.ElementHeights.Visina3 = 0;
                }

                if (duzina >= 4)
                {
                    if (vrijednost[3] <= 5 && vrijednost[3] > 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina4 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[3]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja4 = "Green";
                        ViewModel.DataChartViewModel.ElementHeights.FourthTime = DateTime.Now.ToString("HH:mm");
                      


                    }
                    else if (vrijednost[3] > 5 || vrijednost[3] == 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina4 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[3]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja4 = "Red";
                        ViewModel.DataChartViewModel.ElementHeights.FourthTime = DateTime.Now.ToString("HH:mm");
                       

                    }
                }
                else
                {
                    ViewModel.DataChartViewModel.ElementHeights.Visina4 = 0;
                }

                if (duzina >= 5)
                {
                    if (vrijednost[4] <= 5 && vrijednost[4] > 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina5 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[4]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja5 = "Green";
                        ViewModel.DataChartViewModel.ElementHeights.FifthTime= DateTime.Now.ToString("HH:mm");

                    }
                    else if (vrijednost[4] > 5 || vrijednost[4] == 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina5 = ViewModel.DataChartViewModel.CalculateElementHeight(vrijednost[4]);
                        ViewModel.DataChartViewModel.ElementHeights.Boja5 = "Red";
                        ViewModel.DataChartViewModel.ElementHeights.FifthTime = DateTime.Now.ToString("HH:mm");

                    }
                }
                else
                {
                    ViewModel.DataChartViewModel.ElementHeights.Visina5 = 0;
                }
            }
        }

        public static double CalculateElementHeight(double value)
        {
            double minValue = 0;
            double maxValue = 9;
            double minY = 30;
            double maxY = 270;

            return minY + ((maxValue - value) / (maxValue - minValue)) * (maxY - minY);
        }

        
    }
}
