﻿using NetworkService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace NetworkService.ViewModel
{
    public class MainWindowViewModel : BindableBase
    {
       // private int count = 15; // Inicijalna vrednost broja objekata u sistemu
                                // ######### ZAMENITI stvarnim brojem elemenata
                                //           zavisno od broja entiteta u listi
        
        public MainWindowViewModel()
        {
           // createListener(); //Povezivanje sa serverskom aplikacijom
            NavCommand = new MyICommand<string>(OnNav);
            CurrentViewModel = networkDataViewModel;
            terminal = new MyICommand<TextBox>(Terminal);
          
        }

        //private void createListener()
        //{
        //    var tcp = new TcpListener(IPAddress.Any, 25675);
        //    tcp.Start();

        //    var listeningThread = new Thread(() =>
        //    {
        //        while (true)
        //        {
        //            var tcpClient = tcp.AcceptTcpClient();
        //            ThreadPool.QueueUserWorkItem(param =>
        //            {
        //                //Prijem poruke
        //                NetworkStream stream = tcpClient.GetStream();
        //                string incomming;
        //                byte[] bytes = new byte[1024];
        //                int i = stream.Read(bytes, 0, bytes.Length);
        //                //Primljena poruka je sacuvana u incomming stringu
        //                incomming = System.Text.Encoding.ASCII.GetString(bytes, 0, i);

        //                //Ukoliko je primljena poruka pitanje koliko objekata ima u sistemu -> odgovor
        //                if (incomming.Equals("Need object count"))
        //                {
        //                    //Response
        //                    /* Umesto sto se ovde salje count.ToString(), potrebno je poslati 
        //                     * duzinu liste koja sadrzi sve objekte pod monitoringom, odnosno
        //                     * njihov ukupan broj (NE BROJATI OD NULE, VEC POSLATI UKUPAN BROJ)
        //                     * */
        //                    Byte[] data = System.Text.Encoding.ASCII.GetBytes(count.ToString());
        //                    stream.Write(data, 0, data.Length);
        //                }
        //                else
        //                {
        //                    //U suprotnom, server je poslao promenu stanja nekog objekta u sistemu
        //                    Console.WriteLine(incomming); //Na primer: "Entitet_1:272"

        //                    //################ IMPLEMENTACIJA ####################
        //                    // Obraditi poruku kako bi se dobile informacije o izmeni
        //                    // Azuriranje potrebnih stvari u aplikaciji

        //                }
        //            }, null);
        //        }
        //    });

        //    listeningThread.IsBackground = true;
        //    listeningThread.Start();
        //}

        public MyICommand<string> NavCommand { get; private set; }
        private NetworkDataViewModel networkDataViewModel = new NetworkDataViewModel();
        private NetworkViewViewModel networkViewViewModel = new NetworkViewViewModel();
        private DataChartViewModel dataChartViewModel = new DataChartViewModel();
        private BindableBase currentViewModel;
        public int monitor = 0;

        private string help = "List of commands: \n\n" +
            "- add(id,name,type)"+
            "- type - solar/air\n" +
            "- delete(id)\n" +
            "- search(name/type,value)\n" +
            "- graph(id)\n" +
            "- SecondTab\n" +
            "- ThirdTab\n" +
            "- FirstTab\n" +
            "- undo\n";

        private bool ind = false;
        public MyICommand<TextBox> terminal { get; set; }



        public void Terminal(TextBox tb)
        {
            string[] p;
            string f = "";
            if (ind == true)
            {
                f = tb.Text.Substring(help.Length);
                p = f.Split('(', ')', ',');
                ind = false;
            }
            else
            {
                p = tb.Text.Split('(', ')', ',');
                f = tb.Text;
            }

            if (p[0] == "help" && p.Length == 1)
            {
                ind = true;
                tb.Text = help;
                tb.FontSize = 16;

            }
            else if (p[0] == "add")
            {
                NetworkDataViewModel.AddCommand.Execute(f);
                tb.Text = "";
            }
            else if (p[0] == "delete")
            {
                NetworkDataViewModel.DeleteCommand.Execute(f);
                tb.Text = "";

            }
            else if (p[0] == "ThirdTab")
            {
                CurrentViewModel = dataChartViewModel;
                tb.Text = "";
            }
            else if (p[0] == "SecondTab")
            {
                CurrentViewModel = networkViewViewModel;
                tb.Text = "";
            }
            else if (p[0] == "FirstTab")
            {
                CurrentViewModel = networkDataViewModel;
                tb.Text = "";
            }
            else if (p[0] == "undo")
            {
                NetworkDataViewModel.UndoCommand.Execute(f);
                tb.Text = "";
            }
            else if (p[0] == "graph")
            {
                CurrentViewModel = dataChartViewModel;
                DataChartViewModel.PlotCommand.Execute(f);
                tb.Text = "";
            }
            else if (p[0] == "search")
            {
                NetworkDataViewModel.SearchCommandConsole.Execute(f);
                tb.Text = "";
            }
            else
            {
                MessageBox.Show("Unknown command", "Warning!", MessageBoxButton.OK, MessageBoxImage.Warning);
                tb.Text = "";
            }
        }






        public BindableBase CurrentViewModel
        {
            get { return currentViewModel; }
            set
            {
                SetProperty(ref currentViewModel, value);
            }
        }

        private void OnNav(string destination)
        {
            switch (destination)
            {
                case "NetworkData":
                    CurrentViewModel = networkDataViewModel;
                    break;
                case "NetworkView":
                    CurrentViewModel = networkViewViewModel;
                    break;

                case "DataChart":
                    CurrentViewModel = dataChartViewModel;
                    break;
            }
        }
    }
    }

