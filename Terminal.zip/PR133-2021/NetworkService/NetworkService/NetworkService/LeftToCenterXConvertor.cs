﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace NetworkService.Converters
{
    // Konverter za pretvaranje Canvas.Left u X koordinatu sredine elipse
    public class LeftToCenterXConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double left = (double)value;
            double width = double.Parse(parameter.ToString());
            return left + width / 2;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    // Konverter za pretvaranje Canvas.Top u Y koordinatu sredine elipse
    public class TopToCenterYConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double top = (double)value;
            double height = double.Parse(parameter.ToString());
            return top + height / 2;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    // Konverter za pretvaranje razlike između X koordinata u dužinu linije
    public class DeltaXToLineLengthConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double deltaX = (double)value;
            return Math.Abs(deltaX);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    // Konverter za pretvaranje razlike između Y koordinata u visinu linije
    public class DeltaYToLineHeightConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double deltaY = (double)value;
            return Math.Abs(deltaY);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
