﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace NetworkService.Model
{

    public class MyLine : BindableBase
    {
        private Point _start;
        private Point _end;
        private Brush _stroke;
        private double _thickness;

        public Point Start
        {
            get { return _start; }
            set { SetProperty(ref _start, value); }
        }

        public Point End
        {
            get { return _end; }
            set { SetProperty(ref _end, value); }
        }

        public Brush Stroke
        {
            get { return _stroke; }
            set { SetProperty(ref _stroke, value); }
        }

        public double Thickness
        {
            get { return _thickness; }
            set { SetProperty(ref _thickness, value); }
        }
    }
}

