﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace NetworkService.Model
{
    public class DataBase
    {
        public static ObservableCollection<EntityBase> Entities { get; set; } = new ObservableCollection<EntityBase>();
        public static Dictionary<string, EntityBase> CanvasObjects { get; set; } = new Dictionary<string, EntityBase>();
    }

    public class EntityBase : BindableBase
    {

        private int id;
        private string name;
        private Type type = new Type();
        private double value;
        public int Id
        {
            get { return id; }
            set
            {
                id = value;
            }
        }
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
            }
        }
        private Queue<double> previousValues = new Queue<double>();
        private const int MaxPreviousValues = 5;


        public double Value
        {
            get { return value; }
            set
            {
                if (previousValues.Count == MaxPreviousValues)
                {
                    previousValues.Dequeue(); // Uklonite najstariju vrednost ako je dostignut maksimalni broj prethodnih vrednosti
                }
                previousValues.Enqueue(this.value); // Dodajte trenutnu vrednost kao novu prethodnu vrednost

                this.value = value;
                OnPropertyChanged("Value");

                int a = ViewModel.DataChartViewModel.EntityChoice;
                if (a == this.id)
                {
                    var previousValuesArray = previousValues.ToArray();
                    if (value > 0 && value <= 5)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina1 = ViewModel.DataChartViewModel.CalculateElementHeight(value);
                        ViewModel.DataChartViewModel.ElementHeights.Boja1 = "Green";
                        ViewModel.DataChartViewModel.ElementHeights.FirstTime = DateTime.Now.ToString("HH:mm");
                        ViewModel.DataChartViewModel.ElementHeights.Merenje1 = value.ToString();

                        // Postavite prethodne vrednosti ako postoje
                        if (previousValuesArray.Length > 0) ViewModel.DataChartViewModel.ElementHeights.Merenje2 = previousValuesArray[Math.Max(0, previousValuesArray.Length - 1)].ToString();
                        if (previousValuesArray.Length > 1) ViewModel.DataChartViewModel.ElementHeights.Merenje3 = previousValuesArray[Math.Max(0, previousValuesArray.Length - 2)].ToString();
                        if (previousValuesArray.Length > 2) ViewModel.DataChartViewModel.ElementHeights.Merenje4 = previousValuesArray[Math.Max(0, previousValuesArray.Length - 3)].ToString();
                        if (previousValuesArray.Length > 3) ViewModel.DataChartViewModel.ElementHeights.Merenje5 = previousValuesArray[Math.Max(0, previousValuesArray.Length - 4)].ToString();

                    }
                    else if (value > 5 || value == 0)
                    {
                        ViewModel.DataChartViewModel.ElementHeights.Visina1 = ViewModel.DataChartViewModel.CalculateElementHeight(value);
                        ViewModel.DataChartViewModel.ElementHeights.Boja1 = "Red";
                        ViewModel.DataChartViewModel.ElementHeights.FirstTime = DateTime.Now.ToString("HH:mm");
                        ViewModel.DataChartViewModel.ElementHeights.Merenje1 = value.ToString();

                        // Postavite prethodne vrednosti ako postoje
                        if (previousValuesArray.Length > 0) ViewModel.DataChartViewModel.ElementHeights.Merenje2 = previousValuesArray[Math.Max(0, previousValuesArray.Length - 1)].ToString();
                        if (previousValuesArray.Length > 1) ViewModel.DataChartViewModel.ElementHeights.Merenje3 = previousValuesArray[Math.Max(0, previousValuesArray.Length - 2)].ToString();
                        if (previousValuesArray.Length > 2) ViewModel.DataChartViewModel.ElementHeights.Merenje4 = previousValuesArray[Math.Max(0, previousValuesArray.Length - 3)].ToString();
                        if (previousValuesArray.Length > 3) ViewModel.DataChartViewModel.ElementHeights.Merenje5 = previousValuesArray[Math.Max(0, previousValuesArray.Length - 4)].ToString();
                    }
                }
            }
        }
       



        public Type Type
        {
            get { return type; }
            set
            {
                type.Name = value.Name;
                type.Picture = value.Picture;
            }
        }

       
        public EntityBase()
        {
        }
        public EntityBase(EntityBase eb)
        {
            Id = eb.Id;
            Name = eb.Name;
            Type = eb.type;
            Value = eb.Value;
        }
        public bool IsValueValid()
        {
            bool isValid = false;

            if (Value >= 1 && Value <= 7 )
            {
                isValid = true;
            }

            return isValid;
        }
    }
}
